CorsMiddlewareWebSite
===

This web site illustrates how to use CorsMiddleware to apply a policy for entire application.
