CORS
===
AppVeyor: [![AppVeyor](https://ci.appveyor.com/api/projects/status/yi0m8evjtg107o12/branch/dev?svg=true)](https://ci.appveyor.com/project/aspnetci/CORS/branch/dev)

Travis:   [![Travis](https://travis-ci.org/aspnet/CORS.svg?branch=dev)](https://travis-ci.org/aspnet/CORS)

CORS repository includes the core implementation for CORS policy, utilized by the CORS middleware and MVC.

This project is part of ASP.NET Core. You can find samples, documentation and getting started instructions for ASP.NET Core at the [Home](https://github.com/aspnet/home) repo.
